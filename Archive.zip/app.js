//Import packages
const mongoose = require('mongoose');
const express = require("express");
const morgan = require("morgan");
const ejs = require("ejs");

//models
const Doctor = require('./models/doctor');
const Patient = require('./models/patient');

//Configure Express
const app = express();
app.engine("html", ejs.renderFile);
app.set("view engine", "html");
app.use(express.static("css"));
app.use(express.urlencoded({ extended: false }));
app.use(morgan("common"));
app.listen(8080);

// Connection URL
const url = "mongodb://localhost:27017/Lab6";
//reference to the database (i.e. collection)
let db;
//Connect to server
mongoose.connect(url, function (err) {
    if (err) {
        console.log('Error in Mongoose connection : Doctors Database');
        throw err;
    }

    console.log('Successfully connected: Doctor Database');
});

//Home - index.html
app.get("/", function (req, res) {
  res.sendFile(__dirname + "/views/index.html");
});

/*Doctor*/

//add Doctor
app.get("/addDoctor",function(req,res){
    res.sendFile(__dirname + "/views/addDoctor.html");
});

// handler - addnewDoctor
app.post("/addnewDoctor", function (req, res) {
  let doctorRecords = req.body;
  let doctor = new Doctor({
      //_id: new mongoose.Types.ObjectId(),
      name:{
          firstName:doctorRecords.firstName,
          lastName:doctorRecords.lastName
      },
      date: doctorRecords.dob,
      address: {
          state:doctorRecords.state,
          suburb:doctorRecords.suburb,
          street:doctorRecords.street,
          unit:doctorRecords.unit
      },
      numPatient: doctorRecords.numPatient
  });

  doctor.save(function(err){
      if(err) throw err;
      console.log("success to save new Doctor1")
  });
  res.redirect("/getDoctors"); // redirect the client to list books page -- not sure
});

//List all books
app.get("/getDoctors", function (req, res) {
  Doctor.find({},function(err,docs){
      res.render("listDoctors", { doctorDB: docs });
  });
});

//Update doctor:
app.get("/updateDoctor", function (req, res) {
  res.sendFile(__dirname + "/views/updateDoctor.html");
});

//POST request: receive the details from the client and do the update
app.post("/updateDoctorNumP", function (req, res) {
  let doctorData = req.body;

  Doctor.updateOne({'_id':doctorData.id},
  {$set: {'numPatient': doctorData.numPatient}},
  function(err,doc){
      console.log(doc);
  });
  res.redirect("/getDoctors"); // redirect the client to list books page
});

/*Patient */


//Delete book:
app.get("/deleteDoctor", function (req, res) {
  res.sendFile(__dirname + "/views/deletebook.html");
});
app.post("/deletebookRecord", function (req, res) {
  let bookRecords = req.body;
  let filter = { topic: bookRecords.topic };
  db.collection("books").deleteMany(filter);
  res.redirect("/getbooks"); // redirect the client to list books page
});

app.post("/deletebookRecordByDate", function (req, res) {
    let bookRecords = req.body;
    let filter = { dateOfpublication: {$lt: bookRecords.dateOfpublication} };
    db.collection("books").deleteMany(filter);
    res.redirect("/getbooks"); // redirect the client to list books page
  });

app.get("*",function(req,res){
    res.sendFile(__dirname + "/views/404.html");
})